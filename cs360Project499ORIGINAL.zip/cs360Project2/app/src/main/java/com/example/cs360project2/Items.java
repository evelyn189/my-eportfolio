package com.example.cs360project2;

public class Items {
    private String name;
    private int quantity;

    public Items(String name, int quantity) {
        this.name = name;
        this.quantity = quantity;
    }
    //Getter method
    public String getName() {
        return name;
    }
    //Getter Method
    public int getQuantity() {
        return quantity;
    }
    //Getter Method
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}