package com.example.cs360project2;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.content.SharedPreferences;
import android.widget.CompoundButton;
import android.widget.Switch;

public class NotificationSettingActivity extends AppCompatActivity {
    //Declare variables
    private Switch notificationSwitch;
    private SharedPreferences sharedPreferences;
    private static final String PREFS_NAME = "prefs";
    private static final String NOTIFICATION_KEY = "notification_enabled";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sms_permission);
        //Initialize elements and shared preferences
        notificationSwitch = findViewById(R.id.switch1);
        sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        //Initial state of switch
        boolean isNotificationEnabled = sharedPreferences.getBoolean(NOTIFICATION_KEY, false);
        notificationSwitch.setChecked(isNotificationEnabled);
        //Set listener
        notificationSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putBoolean(NOTIFICATION_KEY, isChecked);
                editor.apply();
                //Switch state will enable or disable based on position
                if (isChecked) {
                    enableNotifications();
                } else {
                    disableNotifications();
                }
            }
        });
    }

    private void enableNotifications() {
        // Enable notifications
    }

    private void disableNotifications() {
        // Disable notifications
    }
}
