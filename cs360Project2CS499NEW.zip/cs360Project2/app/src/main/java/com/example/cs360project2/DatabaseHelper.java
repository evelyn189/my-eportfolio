package com.example.cs360project2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 2;  // Incremented database version to handle schema upgrades

    // Constructor for DatabaseHelper
    public DatabaseHelper(Context context) {
        super(context, "userDB", null, DATABASE_VERSION);  // Update database version here
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create the users table with 'email' column
        String createTable = "CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT, email TEXT, password TEXT)";
        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Handle database upgrade by dropping and recreating the table
        if (oldVersion < 2) {  // Only handle upgrade logic if the old version is less than 2
            db.execSQL("DROP TABLE IF EXISTS users");
            onCreate(db);
        }
    }

    // Method to insert a new user into the database
    public void insertUser(String username, String email, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("email", email);
        values.put("password", hashPassword(password));  // Hash the password before saving

        // Insert the values into the 'users' table
        long result = db.insert("users", null, values);
        db.close();

        if (result == -1) {
            Log.e("DatabaseError", "Failed to insert user");
        } else {
            // Log the inserted user data for verification
            checkAllUsers();
        }
    }

    // Method to check if the credentials are valid
    public boolean checkCredentials(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {"username", "password"};
        String selection = "username = ?";
        String[] selectionArgs = {username};

        Cursor cursor = db.query("users", columns, selection, selectionArgs, null, null, null);
        boolean isValidUser = false;

        if (cursor != null && cursor.moveToFirst()) {
            // Get column index for "password"
            int passwordColumnIndex = cursor.getColumnIndex("password");

            if (passwordColumnIndex >= 0) {
                String storedPasswordHash = cursor.getString(passwordColumnIndex);
                isValidUser = storedPasswordHash.equals(hashPassword(password));  // Compare hashed passwords
            } else {
                Log.e("DatabaseError", "Password column not found.");
            }
        } else {
            Log.e("DatabaseError", "No user found with username: " + username);
        }

        cursor.close();
        return isValidUser;
    }

    // Helper method to hash the password using SHA-256
    public String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(password.getBytes());
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                hexString.append(String.format("%02x", b));
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }

    // Method to check all users and log their details
    public void checkAllUsers() {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {"username", "email", "password"};

        // Query to select all users
        Cursor cursor = db.query("users", columns, null, null, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            // Loop through the cursor to fetch user data
            do {
                String username = cursor.getString(cursor.getColumnIndex("username"));
                String email = cursor.getString(cursor.getColumnIndex("email"));
                String password = cursor.getString(cursor.getColumnIndex("password"));

                // Log the user data
                Log.d("UserData", "Username: " + username + ", Email: " + email + ", Password: " + password);
            } while (cursor.moveToNext());
        } else {
            Log.d("UserData", "No users found in the database.");
        }

        cursor.close();
    }
}
