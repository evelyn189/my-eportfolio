package com.example.cs360project2;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class InventoryActivity extends AppCompatActivity {
    //Declare variables
    private RecyclerView recyclerView;
    private ItemAdapter adapter;
    private List<Items> itemList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);
        //Initialize RecyclerView
        recyclerView = findViewById(R.id.recyclerView);

        itemList = new ArrayList<>();
        // Items added to list
        itemList.add(new Items("Item 1", 10));
        itemList.add(new Items("Item 2", 20));

        adapter = new ItemAdapter(itemList);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }
}
