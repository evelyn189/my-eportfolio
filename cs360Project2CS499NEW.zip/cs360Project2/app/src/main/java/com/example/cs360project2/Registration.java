package com.example.cs360project2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Registration extends AppCompatActivity {
    private EditText usernameEditText, emailEditText, passwordEditText;
    private Button registerButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registration_activity);

        // Initialize views
        usernameEditText = findViewById(R.id.username);
        emailEditText = findViewById(R.id.email);
        passwordEditText = findViewById(R.id.password);
        registerButton = findViewById(R.id.register_button);

        // Set up register button click listener
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get user input
                String username = usernameEditText.getText().toString().trim();
                String email = emailEditText.getText().toString().trim();
                String password = passwordEditText.getText().toString().trim();

                // Validate input
                if (username.isEmpty() || email.isEmpty() || password.isEmpty()) {
                    Toast.makeText(Registration.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                } else {
                    // Insert the user into the database
                    DatabaseHelper dbHelper = new DatabaseHelper(Registration.this);
                    dbHelper.insertUser(username, email, password);  // Insert into SQLite database

                    Toast.makeText(Registration.this, "Registration Successful", Toast.LENGTH_SHORT).show();

                    // Start the next activity (MainActivity)
                    Intent intent = new Intent(Registration.this, MainActivity.class);
                    startActivity(intent);
                    finish();  // Close Registration activity
                }
            }
        });
    }
}
