package com.example.cs360project2;
import android.content.Intent;
import android.util.Log;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ItemManagementActivity extends AppCompatActivity {
    //Declare variables
    private EditText itemName;
    private EditText itemQuantity;
    private RecyclerView recyclerView;
    private ItemAdapter itemAdapter;
    private List<Items> itemList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.data_display);
    //Initialize view and buttons
        itemName = findViewById(R.id.item_name);
        itemQuantity = findViewById(R.id.item_quantity);
        recyclerView = findViewById(R.id.recyclerView);
        Button addButton = findViewById(R.id.addButton);
        Button deleteButton = findViewById(R.id.deleteButton);
        Button settingsButton = findViewById(R.id.settingsButton);

        // Initialize the item list and adapter
        itemList = new ArrayList<>();
        itemAdapter = new ItemAdapter(itemList);
        recyclerView.setAdapter(itemAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Set onClick listener for the add button
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("ItemManagementActivity", "Add button clicked");
                String name = itemName.getText().toString().trim();
                String quantityString = itemQuantity.getText().toString().trim();

                // Check if both the fields are filled
                if (!name.isEmpty() && !quantityString.isEmpty()) {
                    try {
                        int quantity = Integer.parseInt(quantityString);

                        // Check if the item exists in the list
                        boolean itemExists = false;
                        for (Items item : itemList) {
                            if (item.getName().equalsIgnoreCase(name)) {
                                // Increase quantity if the item exists
                                item.setQuantity(item.getQuantity() + quantity);
                                itemExists = true;
                                break;
                            }
                        }

                        // Add a new item if item doesn't exists
                        if (!itemExists) {
                            itemList.add(new Items(name, quantity));
                        }

                        // Adapter notified of change
                        itemAdapter.notifyDataSetChanged();
                        itemName.setText("");
                        itemQuantity.setText("");
                    } catch (NumberFormatException e) {
                        // Invalid quantity input
                        Toast.makeText(ItemManagementActivity.this, "Invalid quantity", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    // Show message if fields are empty
                    Toast.makeText(ItemManagementActivity.this, "Enter valid data", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Set onClick listener for the delete button
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = itemName.getText().toString().trim();
                String quantityString = itemQuantity.getText().toString().trim();

                if (!name.isEmpty() && !quantityString.isEmpty()) {
                    try {
                        int deleteQuantity = Integer.parseInt(quantityString);

                        // Find the item on list
                        for (int i = 0; i < itemList.size(); i++) {
                            Items item = itemList.get(i);
                            if (item.getName().equalsIgnoreCase(name)) {
                                if (item.getQuantity() > deleteQuantity) {
                                    item.setQuantity(item.getQuantity() - deleteQuantity);
                                } else if (item.getQuantity() == deleteQuantity) {
                                    itemList.remove(i);
                                } else {
                                    // Show error if greater than quantity
                                    Toast.makeText(ItemManagementActivity.this, "Insufficient quantity to delete", Toast.LENGTH_SHORT).show();
                                    return;
                                }

                                // Notify the adapter of the data change
                                itemAdapter.notifyDataSetChanged();
                                itemName.setText("");
                                itemQuantity.setText("");
                                break;
                            }
                        }
                    } catch (NumberFormatException e) {
                        // Invalid quantity input
                        Toast.makeText(ItemManagementActivity.this, "Invalid quantity", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    // Show message if fields are empty
                    Toast.makeText(ItemManagementActivity.this, "Enter valid data", Toast.LENGTH_SHORT).show();
                }
            }
        });


        settingsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Transition to SettingsActivity
                Intent intent = new Intent(ItemManagementActivity.this, NotificationSettingActivity.class);
                startActivity(intent);
            }
        });
    }}